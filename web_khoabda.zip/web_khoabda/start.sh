echo "Starting..."; docker-compose up -d; 

