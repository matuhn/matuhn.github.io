#!/bin/sh
chown root:root /src -R
chown shell:shell /src/logs -R
chown shell:shell /src/scripts -R
chmod 775 * -R
apt update
apt install iptables dnsutils iputils-ping
