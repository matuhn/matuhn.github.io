<?php

if (!defined('check_access')) 
{
  die("IMPOSTOR ALERT!!!");
}

?>
<div class="navbar">
  <a href="?page=home" class="active">Home</a>
  <a href="?page=crew">Crew</a>
  <a href="?page=map">Map</a>
  <a href="?page=cafeteria">Cafeteria</a>
  <a href="?page=medbay">MedBay</a>
  <a href="?page=electrical">Electrical</a>
  <a href="?page=o2">O2</a>
  <a href="?page=forgot" class="right">Forgot</a>
  <a href="?page=login" class="right">Login</a>
</div>

<p class="map">
<img src="assets/crew.png" width="55%"/>
</p>